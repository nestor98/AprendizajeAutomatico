function yhat = clasificacionBayesiana( modelo, X)
% Con los modelos entrenados, predice la clase para cada muestra X




